﻿namespace TicTacToe.Models
{
    public class GameState
    {
        public string[,] Board { get; set; } = new string[3, 3];
        public string CurrentPlayer { get; set; } = "X";
        public bool IsGameOver { get; set; } = false;
        public string? Winner { get; set; } = null;
        public bool IsSinglePlayer { get; set; } = false;

        public GameState()
        {
            ResetBoard();
        }

        public void ResetBoard()
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    Board[i, j] = string.Empty;

            CurrentPlayer = "X";
            IsGameOver = false;
            Winner = null;
        }

        public bool MakeMove(int row, int col)
        {
            if (!string.IsNullOrEmpty(Board[row, col]) || IsGameOver)
                return false;

            Board[row, col] = CurrentPlayer;
            CheckWinner();

            if (!IsGameOver)
            {
                CurrentPlayer = (CurrentPlayer == "X") ? "O" : "X";
            }

            return true;
        }

        public (int, int)? GetBestAIMove()
        {
            int bestScore = int.MinValue;
            (int, int)? bestMove = null;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (string.IsNullOrEmpty(Board[i, j]))
                    {
                        Board[i, j] = "O"; // Simulate AI move
                        int score = Minimax(Board, false);
                        Board[i, j] = ""; // Undo move

                        if (score > bestScore)
                        {
                            bestScore = score;
                            bestMove = (i, j);
                        }
                    }
                }
            }

            return bestMove;
        }

        private int Minimax(string[,] board, bool isMaximizing)
        {
            string result = CheckWinnerForMinimax();
            if (result == "O") return 1;
            if (result == "X") return -1;
            if (result == "Draw") return 0;

            int bestScore = isMaximizing ? int.MinValue : int.MaxValue;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (string.IsNullOrEmpty(board[i, j]))
                    {
                        board[i, j] = isMaximizing ? "O" : "X"; // Simulate move
                        int score = Minimax(board, !isMaximizing);
                        board[i, j] = ""; // Undo move

                        bestScore = isMaximizing ? Math.Max(score, bestScore) : Math.Min(score, bestScore);
                    }
                }
            }
            return bestScore;
        }

        private string? CheckWinnerForMinimax()
        {
            string[] lines = {
                $"{Board[0,0]}{Board[0,1]}{Board[0,2]}",
                $"{Board[1,0]}{Board[1,1]}{Board[1,2]}",
                $"{Board[2,0]}{Board[2,1]}{Board[2,2]}",
                $"{Board[0,0]}{Board[1,0]}{Board[2,0]}",
                $"{Board[0,1]}{Board[1,1]}{Board[2,1]}",
                $"{Board[0,2]}{Board[1,2]}{Board[2,2]}",
                $"{Board[0,0]}{Board[1,1]}{Board[2,2]}",
                $"{Board[0,2]}{Board[1,1]}{Board[2,0]}"
            };

            foreach (var line in lines)
            {
                if (line == "XXX") return "X";
                if (line == "OOO") return "O";
            }

            return Board.Cast<string>().Any(cell => string.IsNullOrEmpty(cell)) ? null : "Draw";
        }

        public bool MakeAIMove()
        {
            var move = GetBestAIMove();
            if (move.HasValue)
            {
                return MakeMove(move.Value.Item1, move.Value.Item2);
            }
            return false;
        }

        private void CheckWinner()
        {
            string[] lines = {
                $"{Board[0,0]}{Board[0,1]}{Board[0,2]}",
                $"{Board[1,0]}{Board[1,1]}{Board[1,2]}",
                $"{Board[2,0]}{Board[2,1]}{Board[2,2]}",
                $"{Board[0,0]}{Board[1,0]}{Board[2,0]}",
                $"{Board[0,1]}{Board[1,1]}{Board[2,1]}",
                $"{Board[0,2]}{Board[1,2]}{Board[2,2]}",
                $"{Board[0,0]}{Board[1,1]}{Board[2,2]}",
                $"{Board[0,2]}{Board[1,1]}{Board[2,0]}"
            };

            foreach (var line in lines)
            {
                if (line == "XXX")
                {
                    Winner = "X";
                    IsGameOver = true;
                }
                else if (line == "OOO")
                {
                    Winner = "O";
                    IsGameOver = true;
                }
            }

            if (!IsGameOver && !Board.Cast<string>().Any(cell => string.IsNullOrEmpty(cell)))
            {
                IsGameOver = true;
                Winner = null;
            }
        }
    }
}
