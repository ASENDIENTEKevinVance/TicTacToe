﻿using Microsoft.AspNetCore.SignalR;
using TicTacToe.Models;

namespace TicTacToe.Hubs
{
    public class GameHub : Hub
    {
        private static GameState _gameState = new GameState();

        public async Task StartGame(bool isSinglePlayer)
        {
            _gameState.ResetBoard();
            _gameState.IsSinglePlayer = isSinglePlayer;
            await Clients.All.SendAsync("ResetBoard");
        }

        public async Task MakeMove(int row, int col)
        {
            if (_gameState.Board[row, col] == string.Empty && !_gameState.IsGameOver)
            {
                string currentPlayer = _gameState.CurrentPlayer;

                // Make the move for the current player
                if (_gameState.MakeMove(row, col))
                {
                    // Send move update to all clients
                    await Clients.All.SendAsync("ReceiveMove", row, col, currentPlayer, _gameState.IsGameOver, _gameState.Winner);

                    // If game is over, stop further moves
                    if (_gameState.IsGameOver)
                    {
                        await Clients.All.SendAsync("ShowWinner", _gameState.Winner);
                        return;
                    }

                    // Switch turns correctly
                    _gameState.CurrentPlayer = (currentPlayer == "X") ? "O" : "X";

                    // Send turn notification to all players
                    await Clients.All.SendAsync("PlayerTurn", _gameState.CurrentPlayer);

                    // If single-player mode and it's AI's turn, let AI play
                    if (_gameState.IsSinglePlayer && _gameState.CurrentPlayer == "O")
                    {
                        await Task.Delay(500); // Simulate AI thinking time

                        var aiMove = _gameState.GetBestAIMove();
                        if (aiMove.HasValue)
                        {
                            _gameState.MakeMove(aiMove.Value.Item1, aiMove.Value.Item2);

                            // Send AI move update
                            await Clients.All.SendAsync("ReceiveMove", aiMove.Value.Item1, aiMove.Value.Item2, "O", _gameState.IsGameOver, _gameState.Winner);

                            // If AI wins, notify
                            if (_gameState.IsGameOver)
                            {
                                await Clients.All.SendAsync("ShowWinner", _gameState.Winner);
                                return;
                            }

                            // Notify that it's the player's turn
                            _gameState.CurrentPlayer = "X";
                            await Clients.All.SendAsync("PlayerTurn", "X");
                        }
                    }
                }
            }
        }
    }
}
