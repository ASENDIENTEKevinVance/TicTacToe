﻿const connection = new signalR.HubConnectionBuilder()
    .withUrl("/gameHub")
    .build();

let turn = document.getElementById("turnIndicator");
let playerXScore = 0;
let playerOScore = 0;
let drawScore = 0;
let gameActive = true;

connection.start()
    .then(() => {
        console.log("Connected to hub");
        startGame();
    })
    .catch(err => console.error(err));

function startGame() {
    gameActive = true;
    connection.invoke("StartGame", false)
        .catch(err => console.error(err));

    document.getElementById("board").style.display = "grid";
    document.getElementById("reset").style.display = "block";
    document.getElementById("scoreboard").style.display = "block";
    document.getElementById("turnIndicator").style.display = "block";
    document.querySelectorAll('.cell').forEach(cell => cell.textContent = '');
    document.getElementById("status").textContent = '';
}

document.querySelectorAll('.cell').forEach(cell => {
    cell.addEventListener('click', function () {
        if (!gameActive) return;

        const row = parseInt(this.getAttribute("data-row"));
        const col = parseInt(this.getAttribute("data-col"));
        if (this.textContent !== '') return; // Prevent clicking filled cells

        connection.invoke("MakeMove", row, col)
            .catch(err => console.error(err));
    });
});

connection.on("ReceiveMove", (row, col, player, isGameOver, winner) => {
    const cell = document.querySelector(`[data-row='${row}'][data-col='${col}']`);
    cell.textContent = player;

    if (isGameOver) {
        gameActive = false;
        if (winner === "X") {
            playerXScore++;
            document.getElementById("playerXScore").textContent = `X: ${playerXScore}`;
            document.getElementById("status").textContent = "Player X Wins!";
        } else if (winner === "O") {
            playerOScore++;
            document.getElementById("playerOScore").textContent = `O: ${playerOScore}`;
            document.getElementById("status").textContent = "Player O Wins!";
        } else {
            drawScore++;
            document.getElementById("drawScore").textContent = `Draws: ${drawScore}`;
            document.getElementById("status").textContent = "It's a Draw!";
        }
        turn.textContent = "Game Over!";
    }
});

connection.on("PlayerTurn", (currentPlayer) => {
    if (gameActive) {
        turn.textContent = `Turn: ${currentPlayer}`;
    }
});

connection.on("ResetBoard", () => {
    gameActive = true;
    document.querySelectorAll('.cell').forEach(cell => cell.textContent = '');
    document.getElementById("status").textContent = '';
    turn.textContent = "Turn: X";
});

document.getElementById("reset").addEventListener("click", startGame);