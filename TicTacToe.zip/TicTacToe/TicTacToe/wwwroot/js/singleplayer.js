﻿let currentPlayer = 'X';
let gameBoard = Array(3).fill(null).map(() => Array(3).fill(''));
let gameActive = true;
let playerScore = 0;
let aiScore = 0;
let drawScore = 0;

function startGame() {
    gameBoard = Array(3).fill(null).map(() => Array(3).fill(''));
    currentPlayer = 'X';
    gameActive = true;
    document.querySelectorAll('.cell').forEach(cell => cell.textContent = '');
    document.getElementById('turnIndicator').textContent = 'Turn: X';
    document.getElementById('status').textContent = '';
    document.getElementById('scoreboard').style.display = 'block';
}

function handleCellClick(e) {
    if (!gameActive || currentPlayer !== 'X') return;

    const row = parseInt(e.target.getAttribute('data-row'));
    const col = parseInt(e.target.getAttribute('data-col'));

    if (gameBoard[row][col] !== '') return;

    makeMove(row, col, 'X');

    if (checkGameState()) return;

    currentPlayer = 'O';
    document.getElementById('turnIndicator').textContent = 'Turn: O';
    setTimeout(makeAIMove, 500);
}

function makeAIMove() {
    if (!gameActive) return;

    const difficulty = document.getElementById('difficulty').value;
    let move;

    switch (difficulty) {
        case 'easy':
            move = Math.random() < 0.9 ? getRandomMove() : getBestMove();
            break;
        case 'medium':
            move = Math.random() < 0.6 ? getRandomMove() : getBestMove();
            break;
        case 'hard':
            move = getBestMove();
            break;
        default:
            move = getRandomMove();
    }

    if (move) {
        makeMove(move.row, move.col, 'O');
        checkGameState();
        currentPlayer = 'X';
        if (gameActive) {
            document.getElementById('turnIndicator').textContent = 'Turn: X';
        }
    }
}

function makeMove(row, col, player) {
    gameBoard[row][col] = player;
    document.querySelector(`[data-row="${row}"][data-col="${col}"]`).textContent = player;
}

function getBestMove() {
    let bestScore = -Infinity;
    let bestMove;

    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (gameBoard[i][j] === '') {
                gameBoard[i][j] = 'O';
                let score = minimax(gameBoard, 0, false);
                gameBoard[i][j] = '';
                if (score > bestScore) {
                    bestScore = score;
                    bestMove = { row: i, col: j };
                }
            }
        }
    }
    return bestMove;
}

function getRandomMove() {
    let availableMoves = [];
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (gameBoard[i][j] === '') {
                availableMoves.push({ row: i, col: j });
            }
        }
    }
    if (availableMoves.length === 0) return null;
    return availableMoves[Math.floor(Math.random() * availableMoves.length)];
}

function minimax(board, depth, isMaximizing) {
    let result = checkWinner();
    if (result !== null) {
        return result === 'O' ? 10 - depth : result === 'X' ? depth - 10 : 0;
    }

    if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                if (board[i][j] === '') {
                    board[i][j] = 'O';
                    let score = minimax(board, depth + 1, false);
                    board[i][j] = '';
                    bestScore = Math.max(score, bestScore);
                }
            }
        }
        return bestScore;
    } else {
        let bestScore = Infinity;
        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                if (board[i][j] === '') {
                    board[i][j] = 'X';
                    let score = minimax(board, depth + 1, true);
                    board[i][j] = '';
                    bestScore = Math.min(score, bestScore);
                }
            }
        }
        return bestScore;
    }
}

function checkWinner() {
    // Check rows, columns and diagonals
    for (let i = 0; i < 3; i++) {
        if (gameBoard[i][0] && gameBoard[i][0] === gameBoard[i][1] && gameBoard[i][0] === gameBoard[i][2]) return gameBoard[i][0];
        if (gameBoard[0][i] && gameBoard[0][i] === gameBoard[1][i] && gameBoard[0][i] === gameBoard[2][i]) return gameBoard[0][i];
    }
    if (gameBoard[0][0] && gameBoard[0][0] === gameBoard[1][1] && gameBoard[0][0] === gameBoard[2][2]) return gameBoard[0][0];
    if (gameBoard[0][2] && gameBoard[0][2] === gameBoard[1][1] && gameBoard[0][2] === gameBoard[2][0]) return gameBoard[0][2];

    // Check for draw
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (gameBoard[i][j] === '') return null;
        }
    }
    return 'draw';
}

function checkGameState() {
    const winner = checkWinner();
    if (winner !== null) {
        gameActive = false;
        if (winner === 'X') {
            playerScore++;
            document.getElementById('playerXScore').textContent = `Win: ${playerScore}`;
            document.getElementById('status').textContent = 'You Win!';
        } else if (winner === 'O') {
            aiScore++;
            document.getElementById('playerOScore').textContent = `Loss: ${aiScore}`;
            document.getElementById('status').textContent = 'AI Wins!';
        } else {
            drawScore++;
            document.getElementById('drawScore').textContent = `Draws: ${drawScore}`;
            document.getElementById('status').textContent = "It's a Draw!";
        }
        document.getElementById('turnIndicator').textContent = 'Game Over!';
        return true;
    }
    return false;
}

document.querySelectorAll('.cell').forEach(cell => {
    cell.addEventListener('click', handleCellClick);
});

document.getElementById('reset').addEventListener('click', startGame);
document.getElementById('difficulty').addEventListener('change', startGame);

startGame();